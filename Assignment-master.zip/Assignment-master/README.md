# Assignment
API which will serve a POST request accepts a JSON containing an array of addresses and return their location in the form of latitude and longitude.

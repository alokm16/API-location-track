package com.example.Assignment;

public class Location {
    private String add;
    private double[] location;

    public String getAdd() {
        return add;
    }

    public double[] getLocation() {
        return location;
    }

    public void setAdd(String add) {
        this.add = add;
    }

    public void setLocation(double[] location) {
        this.location = location;
    }

}
